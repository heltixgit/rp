#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

uniform sampler2D Sampler0;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec2 texSize = textureSize(Sampler0, 0);
    ivec3 rgb = ivec3(Color.rgb * 255.0 + 0.5);
    bool isTargetColor = (rgb == ivec3(0, 1, 1));
    bool isPlayerSkin = (texSize.x == 64 && (texSize.y == 64 || texSize.y == 32));

    bool isGUI = (ProjMat[2][3] == 0.0);

    if (isPlayerSkin && isTargetColor) {
        col.rgb = vec3(1.0);
        if (!isGUI) {
          //  pos.y += 0.02;
        } else {
            pos.y += 1.0;
        }
    } else if (isTargetColor) {
        col.rgb = vec3(1.0);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    #if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    #else
    vertexColor = col;
    #endif

    texCoord0 = UV0;
}
