#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec2 texSize = textureSize(Sampler0, 0);
    ivec3 rgb = ivec3(Color.rgb * 255.0 + 0.5);
    bool isTargetColor = (rgb == ivec3(0, 1, 1));
    if (isTargetColor) {
        col.rgb = vec3(1.0);
        if (texSize.x > 256 || texSize.y > 256) {
            int corner = gl_VertexID % 4;
            float deltaU = 16.0 / float(texSize.x);
            float deltaV = 16.0 / float(texSize.y);
            float u_min, u_max, v_min, v_max;
            if (corner == 0) {
                u_min = UV0.x; u_max = UV0.x + deltaU;
                v_min = UV0.y; v_max = UV0.y + deltaV;
            } else if (corner == 1) {
                u_min = UV0.x; u_max = UV0.x + deltaU;
                v_min = UV0.y - deltaV; v_max = UV0.y;
            } else if (corner == 2) {
                u_min = UV0.x - deltaU; u_max = UV0.x;
                v_min = UV0.y - deltaV; v_max = UV0.y;
            } else {
                u_min = UV0.x - deltaU; u_max = UV0.x;
                v_min = UV0.y; v_max = UV0.y + deltaV;
            }
            int firstRow = -1;
            int lastRow = -1;
            for (int r = 0; r < 16; r++) {
                float v_sample = v_min + (float(r) + 0.5) * (v_max - v_min) / 16.0;
                bool rowHasPixels = false;
                for (int c = 0; c < 8; c++) {
                    float u_sample = u_min + (float(c) + 0.5) * (u_max - u_min) / 8.0;
                    if (textureLod(Sampler0, vec2(u_sample, v_sample), 0.0).a > 0.1) {
                        rowHasPixels = true;
                        break;
                    }
                }
                if (rowHasPixels) {
                    if (firstRow == -1) firstRow = r;
                    lastRow = r;
                }
            }
            int spriteHeight = (firstRow != -1 && lastRow != -1) ? (lastRow - firstRow + 1) : 16;
            vec2 scale = vec2(0.0);
            if (spriteHeight < 16) {
                scale = vec2(2.0, 2.0);
            } else if (spriteHeight < 17) {
                scale = vec2(0.5, 0.5);
            }
            if (corner == 0) pos.xy += vec2(-scale.x, -scale.y);
            else if (corner == 1) pos.xy += vec2(-scale.x, scale.y);
            else if (corner == 2) pos.xy += vec2(scale.x, scale.y);
            else if (corner == 3) pos.xy += vec2(scale.x, -scale.y);
            if (firstRow != -1 && lastRow != -1) {
                float rowShift = (float(firstRow + lastRow) - 15.0) / 2.0;
                pos.y -= rowShift * 0.5;
            }
            pos.y += 0.5;
        }
    }
    bool isPlayerSkin = (texSize.x == 64 && (texSize.y == 64 || texSize.y == 32));
    if (isPlayerSkin) {
        pos.y += 1.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
