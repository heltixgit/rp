#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;

invariant gl_Position;

vec4 heltix_item_position(vec3 position) {
    vec4 view = ModelViewMat * vec4(position, 1.0);
    if (ProjMat[3][3] == 1.0) {
        view.z += 10.0;
    } else {
        float depthFar = ProjMat[2][2] > 0.5 ? ProjMat[3][2] / (ProjMat[2][2] - 1.0) : ProjMat[3][2] / ProjMat[2][2];
        float dist = length(view.xyz);
        float scale = abs(depthFar - 100.0) < 1.0 ? 0.96 : 1.0 - 0.04 / max(dist, 1.0);
        scale = max(scale, min(1.0, 0.055 / max(-view.z, 0.000001)));
        view.xyz *= scale;
    }
    return ProjMat * view;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    gl_Position = heltix_item_position(Position);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    // подложка редкости (heltix:item/rarity_background) - без освещения
    if (ProjMat[3][3] == 1.0 && abs((ModelViewMat * vec4(Position, 1.0)).z) > 100.0) {
        vertexColor = Color;
    }
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}
