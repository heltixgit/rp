#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

#ifdef IS_GUI
const float TAU = 6.2831853;
const vec3 GLINT_MARKER = vec3(0.0, 1.0, 5.0) / 255.0;
const vec3 COMPACT_MARKER = vec3(0.0, 1.0, 6.0) / 255.0;
const vec3 COMPACT_GLINT_MARKER = vec3(0.0, 1.0, 7.0) / 255.0;
const int COMPACT_SAMPLES = 4;
const vec3 GLINT_TINT = vec3(0.9684, 0.4628, 1.5687);
const float GLINT_MEAN = 0.35849;
const float GLINT_ANGLE = 0.1745329;
const float GLINT_TILES_PER_SPRITE = 0.09;
const vec4 GLINT_WAVES[32] = vec4[](
    vec4(4.0, 0.0, 0.05222, -2.7151),
    vec4(2.0, 4.0, 0.05131, -2.4816),
    vec4(6.0, 0.0, 0.04111, 0.2448),
    vec4(3.0, 6.0, 0.04023, -2.5144),
    vec4(2.0, 0.0, 0.03928, 2.3708),
    vec4(1.0, 2.0, 0.03848, -0.6393),
    vec4(12.0, 0.0, 0.02425, 0.1331),
    vec4(10.0, 0.0, 0.02412, 2.7269),
    vec4(5.0, 10.0, 0.02210, 0.1975),
    vec4(6.0, 12.0, 0.02113, 0.9197),
    vec4(16.0, 0.0, 0.01793, 2.7483),
    vec4(28.0, 0.0, 0.01557, -1.9296),
    vec4(20.0, 0.0, 0.01532, 0.4449),
    vec4(8.0, 16.0, 0.01445, -2.5100),
    vec4(10.0, 20.0, 0.01112, 1.7036),
    vec4(18.0, 0.0, 0.01103, 2.8440),
    vec4(8.0, 0.0, 0.01063, 1.5217),
    vec4(24.0, 0.0, 0.00998, 2.3417),
    vec4(42.0, 0.0, 0.00992, -1.0974),
    vec4(4.0, 8.0, 0.00953, 1.9839),
    vec4(9.0, 18.0, 0.00953, 0.7958),
    vec4(60.0, 0.0, 0.00912, -0.2472),
    vec4(26.0, 0.0, 0.00803, 2.2342),
    vec4(14.0, 28.0, 0.00761, -0.1143),
    vec4(22.0, 0.0, 0.00715, -1.5884),
    vec4(12.0, 24.0, 0.00690, -2.5070),
    vec4(14.0, 0.0, 0.00677, 1.9502),
    vec4(48.0, 0.0, 0.00668, -0.1067),
    vec4(56.0, 0.0, 0.00649, 0.5779),
    vec4(46.0, 0.0, 0.00615, -0.0773),
    vec4(50.0, 0.0, 0.00559, -0.1217),
    vec4(36.0, 0.0, 0.00556, -2.1787)
);

bool hasMarker(vec3 marker) {
    return all(lessThan(abs(vertexColor.rgb - marker), vec3(0.002)));
}

vec4 compactSample(vec4 nearest) {
    vec2 footprint = fwidth(texCoord0);
    if (max(footprint.x, footprint.y) * float(textureSize(Sampler0, 0).x) <= 1.0) {
        return nearest;
    }
    vec3 color = vec3(0.0);
    float alpha = 0.0;
    for (int x = 0; x < COMPACT_SAMPLES; x++) {
        for (int y = 0; y < COMPACT_SAMPLES; y++) {
            vec2 offset = (vec2(x, y) + 0.5) / float(COMPACT_SAMPLES) - 0.5;
            vec4 texel = textureLod(Sampler0, texCoord0 + footprint * offset, 0.0);
            color += texel.rgb * texel.a;
            alpha += texel.a;
        }
    }
    return alpha > 0.0 ? vec4(color / alpha, alpha / float(COMPACT_SAMPLES * COMPACT_SAMPLES)) : vec4(0.0);
}

vec3 glintLight() {
    vec2 sprite = texCoord0 * vec2(textureSize(Sampler0, 0)) / 32.0 * GLINT_TILES_PER_SPRITE;
    vec2 point = mat2(cos(GLINT_ANGLE), sin(GLINT_ANGLE), -sin(GLINT_ANGLE), cos(GLINT_ANGLE)) * sprite + vec2(-44.0, 160.0) * GameTime;
    float value = GLINT_MEAN;
    for (int i = 0; i < 32; i++) {
        vec4 wave = GLINT_WAVES[i];
        value += wave.z * cos(TAU * dot(wave.xy, point) + wave.w);
    }
    vec3 glint = max(value, 0.0) * GLINT_TINT * GlintAlpha;
    return glint * glint;
}
#endif

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_GUI
    bool compact = hasMarker(COMPACT_MARKER) || hasMarker(COMPACT_GLINT_MARKER);
    bool glint = hasMarker(GLINT_MARKER) || hasMarker(COMPACT_GLINT_MARKER);
    if (compact || glint) {
        vec4 sprite = (compact ? compactSample(texColor) : texColor) * vec4(1.0, 1.0, 1.0, vertexColor.a) * ColorModulator;
        if (sprite.a < 0.1) {
            discard;
        }
        fragColor = vec4(glint ? sprite.rgb + glintLight() : sprite.rgb, sprite.a);
        return;
    }
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
