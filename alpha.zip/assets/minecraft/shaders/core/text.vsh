#version 330
#ifdef VULKAN
#extension GL_EXT_spirv_intrinsics : require
spirv_decorate(extensions = ["SPV_KHR_shader_draw_parameters"], capabilities = [4427], 11, 4424) in int spriteBaseVertex;
#define HAS_BASE_VERTEX
#else
#extension GL_ARB_shader_draw_parameters : enable
#ifdef GL_ARB_shader_draw_parameters
#define spriteBaseVertex gl_BaseVertexARB
#define HAS_BASE_VERTEX
#endif
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

uniform sampler2D Sampler0;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec2 texSize = textureSize(Sampler0, 0);
    ivec3 rgb = ivec3(Color.rgb * 255.0 + 0.5);
    bool isTargetColor = (rgb == ivec3(0, 1, 1));
    bool isItemSprite = (rgb == ivec3(0, 1, 2));
    bool isBlockSprite = (rgb == ivec3(0, 1, 3));
    bool isContentsSprite = (rgb.r == 0 && rgb.g == 1 && rgb.b >= 4 && rgb.b <= 13);
    bool isCompactSprite = (rgb.r == 0 && rgb.g == 1 && rgb.b >= 14 && rgb.b <= 23);
    bool isIconSprite = (rgb.r == 0 && rgb.g == 1 && (rgb.b == 24 || rgb.b == 25));
    bool isPlayerSkin = (texSize.x == 64 && (texSize.y == 64 || texSize.y == 32));

    bool isGUI = (ProjMat[2][3] == 0.0);

    if (isPlayerSkin && isTargetColor) {
        col.rgb = vec3(1.0);
        if (!isGUI) {
          //  pos.y += 0.02;
        } else {
            pos.y += 1.0;
        }
    } else if (isTargetColor) {
        col.rgb = vec3(1.0);
    } else if (isContentsSprite) {
        col.rgb = (rgb.b % 2 == 1) ? vec3(0.0, 1.0, 5.0) / 255.0 : vec3(1.0);
        #if defined(IS_GUI) && defined(HAS_BASE_VERTEX)
        int contentsCorner = (gl_VertexID - spriteBaseVertex) % 4;
        pos.x += (contentsCorner < 2) ? -4.0 : 4.0;
        pos.y += (contentsCorner == 0 || contentsCorner == 3) ? -4.0 : 4.0;
        pos.y += 6.0 - float((rgb.b - 4) / 2) * 2.0;
        #endif
    } else if (isCompactSprite) {
        col.rgb = vec3(0.0, 1.0, (rgb.b % 2 == 1) ? 7.0 : 6.0) / 255.0;
        pos.y += 5.0 - float((rgb.b - 14) / 2);
    } else if (isIconSprite) {
        col.rgb = (rgb.b == 25) ? vec3(0.0, 1.0, 5.0) / 255.0 : vec3(1.0);
        #if defined(IS_GUI) && defined(HAS_BASE_VERTEX)
        int iconCorner = (gl_VertexID - spriteBaseVertex) % 4;
        pos.x += (iconCorner < 2) ? -2.0 : 2.0;
        pos.y += (iconCorner == 0 || iconCorner == 3) ? -2.0 : 2.0;
        pos.y += 0.5;
        #endif
    } else if (isItemSprite || isBlockSprite) {
        col.rgb = vec3(1.0);
        if (isGUI && isPlayerSkin) {
            pos.y += 1.0;
        }
        #if defined(IS_GUI) && defined(HAS_BASE_VERTEX)
        int corner = (gl_VertexID - spriteBaseVertex) % 4;
        if (isPlayerSkin) {
            pos.x += (corner < 2) ? -0.5 : 0.5;
            pos.y += (corner == 0 || corner == 3) ? -0.5 : 0.5;
        } else if (texSize.x > 256 || texSize.y > 256) {
            float deltaU = 16.0 / float(texSize.x);
            float deltaV = 16.0 / float(texSize.y);
            float u_min, u_max, v_min, v_max;
            if (corner == 0) {
                u_min = UV0.x; u_max = UV0.x + deltaU;
                v_min = UV0.y; v_max = UV0.y + deltaV;
            } else if (corner == 1) {
                u_min = UV0.x; u_max = UV0.x + deltaU;
                v_min = UV0.y - deltaV; v_max = UV0.y;
            } else if (corner == 2) {
                u_min = UV0.x - deltaU; u_max = UV0.x;
                v_min = UV0.y - deltaV; v_max = UV0.y;
            } else {
                u_min = UV0.x - deltaU; u_max = UV0.x;
                v_min = UV0.y; v_max = UV0.y + deltaV;
            }
            int firstRow = -1;
            int lastRow = -1;
            for (int r = 0; r < 16; r++) {
                float v_sample = v_min + (float(r) + 0.5) * (v_max - v_min) / 16.0;
                bool rowHasPixels = false;
                for (int c = 0; c < 8; c++) {
                    float u_sample = u_min + (float(c) + 0.5) * (u_max - u_min) / 8.0;
                    if (textureLod(Sampler0, vec2(u_sample, v_sample), 0.0).a > 0.1) {
                        rowHasPixels = true;
                        break;
                    }
                }
                if (rowHasPixels) {
                    if (firstRow == -1) firstRow = r;
                    lastRow = r;
                }
            }
            int spriteHeight = (firstRow != -1 && lastRow != -1) ? (lastRow - firstRow + 1) : 16;
            vec2 scale = vec2(0.0);
            if (spriteHeight < 16) {
                scale = vec2(2.0, 2.0);
            } else if (spriteHeight < 17) {
                scale = vec2(0.5, 0.5);
            }
            if (corner == 0) pos.xy += vec2(-scale.x, -scale.y);
            else if (corner == 1) pos.xy += vec2(-scale.x, scale.y);
            else if (corner == 2) pos.xy += vec2(scale.x, scale.y);
            else if (corner == 3) pos.xy += vec2(scale.x, -scale.y);
            if (firstRow != -1 && lastRow != -1) {
                float rowShift = (float(firstRow + lastRow) - 15.0) / 2.0;
                pos.y -= rowShift * 0.5;
            }
            pos.y += isItemSprite ? 1.5 : 0.5;
        }
        #endif
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    #if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    #else
    vertexColor = col;
    #endif

    texCoord0 = UV0;
}
