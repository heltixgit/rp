import os
import json
def get_filtered_textures(base_dir, textures_dir):
    if not os.path.exists(textures_dir):
        return []
    items_dir = os.path.join(base_dir, "assets", "furf", "items")
    models_dir = os.path.join(base_dir, "assets", "furf", "models", "item")
    valid_files = []
    for f in os.listdir(textures_dir):
        if f.endswith(".png"):
            name = os.path.splitext(f)[0]
            item_json = os.path.join(items_dir, f"{name}.json")
            model_json = os.path.join(models_dir, f"{name}.json")
            if not os.path.exists(item_json) or not os.path.exists(model_json):
                valid_files.append(f)
    valid_files.sort(key=lambda x: os.path.getmtime(os.path.join(textures_dir, x)), reverse=True)
    return valid_files
def create_json_files(base_dir, selected_files):
    items_dir = os.path.join(base_dir, "assets", "furf", "items")
    models_dir = os.path.join(base_dir, "assets", "furf", "models", "item")
    os.makedirs(items_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    for file_name in selected_files:
        name = os.path.splitext(file_name)[0]
        item_json_path = os.path.join(items_dir, f"{name}.json")
        model_json_path = os.path.join(models_dir, f"{name}.json")
        if not os.path.exists(item_json_path):
            item_data = {"model": {"type": "minecraft:model", "model": f"furf:item/{name}"}}
            with open(item_json_path, "w", encoding="utf-8") as f:
                json.dump(item_data, f, indent=2)
            print(f"Создан: {item_json_path}")
        if not os.path.exists(model_json_path):
            model_data = {"textures": {"layer0": f"furf:item/{name}"}, "parent": "item/handheld"}
            with open(model_json_path, "w", encoding="utf-8") as f:
                json.dump(model_data, f, indent=2)
            print(f"Создан: {model_json_path}")
def main():
    base_dir = input("Введите путь к папке ресурспака (или Enter для текущей): ").strip().strip('"\'')
    if not base_dir:
        base_dir = os.getcwd()
    if not os.path.exists(base_dir):
        print("Указанный путь не существует.")
        return
    textures_dir = os.path.join(base_dir, "assets", "furf", "textures", "item")
    files = get_filtered_textures(base_dir, textures_dir)
    if not files:
        print("Отлично! Для всех текстур уже созданы необходимые JSON файлы.")
        return
    print(f"\nНайдено файлов без JSON ({len(files)} шт.), сначала новые:")
    for idx, file in enumerate(files, 1):
        print(f"{idx}. {file}")
    user_input = input("\nВведите номера файлов через запятую/пробел (или Enter для всех): ").strip()
    if not user_input or user_input.lower() == 'all':
        selected = files
    else:
        selected = []
        for part in user_input.replace(",", " ").split():
            if part.isdigit() and 0 < int(part) <= len(files):
                selected.append(files[int(part) - 1])
    if not selected:
        print("Ничего не выбрано.")
        return
    create_json_files(base_dir, selected)
if __name__ == "__main__":
    main()
